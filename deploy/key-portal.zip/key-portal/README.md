# Key-Portal (key.luetcke.eu)

Mini-Admin für **Lizenzschlüssel** – **ohne Datenbank**, alles in einer JSON-Datei **`data/licenses.json`**.

## Installation

1. Ordner **`key-portal`** auf den Server (z. B. Webroot von `key.luetcke.eu`).
2. **Document Root** = **`key-portal/public`** (nicht der übergeordnete Ordner).
3. Verzeichnis **`data/`** schreibbar: `chmod 775 data` (Webserver-User).
4. **`https://key.luetcke.eu/install.php`** aufrufen → Admin-Passwort setzen.
5. **`install.php` löschen**.
6. Schlüssel unter **`/admin/`** anlegen; Domains zeilenweise (z. B. `localhost`, `kunde.de`).

## CMS (.env)

```env
CMS_LICENSE_VALIDATE_URL=https://key.luetcke.eu/validate-license.php
```

## URLs

| Pfad | Zweck |
|------|--------|
| `/validate-license.php` | POST JSON (vom CMS) |
| `/admin/login.php` | Login |
| `/admin/` | Schlüssel-Übersicht |

## Backup

**`data/licenses.json`** sichern (enthält Passwort-Hash + alle Keys).

## Sicherheit

- Nur **HTTPS**.
- **`install.php`** nach Setup entfernen.
- Ordner **`data/`** liegt **neben** `public/` und ist normalerweise **nicht** öffentlich erreichbar.
