<?php

declare(strict_types=1);

header('Location: /admin/', true, 302);
